# mkdir

> Crea directory.

- Crea una directory nella directory corrente o in un dato percorso:

`mkdir {{directory}}`

- Crea directory ricorsivamente (utile per creare directory annidate):

`mkdir -p {{percorso/alla/directory}}`
