# cls

> Limpar a tela de saída.

- Limpar a tela:

`cls`
