# sw_vers

> Print macOS Software versioning information.

- Print macOS Version:

`sw_vers -productVersion`

- Print macOS Build:

`sw_vers -buildVersion`
