# runsvchdir

> Change the directory `runsvdir` uses by default.

- Switch `runsvdir` directories:

`sudo runsvchdir {{/path/to/directory}}`
