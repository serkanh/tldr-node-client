# imgcat

> A utility to display images directly on the command line.
> Requires a compatible terminal such as iTerm2.

- Display an image on the command line:

`imgcat {{filename}}`
