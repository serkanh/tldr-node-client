# alpine

> 一个电子邮件客户端和usenet新闻组程序,具有pico/nano风格的界面
> 通过IMAP支持大多数现代电子邮件服务

- 正常打开alpine:

`alpine`

- 直接打开写信息界面,并指定电子邮件发送地址:

`alpine {{邮箱地址}}`

- 退出alpine:

`'q' 然后 'y'`
