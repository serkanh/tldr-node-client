# cls

> 清屏.

- 清屏:

`cls`
