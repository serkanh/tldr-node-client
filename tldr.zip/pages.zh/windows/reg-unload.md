# reg unload

> 从使用`reg load`命令加载的注册表中删除数据.

- 从使用`reg load`命令加载的注册表中删除数据:

`reg unload {{键名}}`
