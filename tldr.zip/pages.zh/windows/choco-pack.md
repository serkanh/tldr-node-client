# choco pack

>  将nuspec打包到已编译的nupkg.

-  将nuspec打包到已编译的nupkg:

`choco pack {{nuspec的路径}}`

-  将nuspec打包到已编译的nupkg,并指定生成的版本:

`choco pack {{nuspec的路径}} --version {{版本号}}`

-  将nuspec打包到已编译的nupkg,并输出到指定的目录:

`choco pack {{nuspec的路径}} --output-directory {{输出目录的路径}}`
