# reg load

> 将保存的子键加载到不同的子键中.
> This is intended for troubleshooting and temporary keys.

- 将备份文件加载到指定的键中:

`reg load {{键名}} {{文件的路径}}`
