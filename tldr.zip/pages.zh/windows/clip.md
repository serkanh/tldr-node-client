# clip

> 将输入的内容复制到Windows的剪贴板.

- 用管道将命令的输出内容复制到Windows剪贴板:

`{{dir}} | clip`

- 将一个文件中的内容复制到Windows剪贴板:

`clip < {{文件的路径}}`
