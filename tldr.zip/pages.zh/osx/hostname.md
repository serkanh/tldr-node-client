# hostname

> 显示或设置系统的主机名.

- 显示本机的主机名:

`hostname`

- 设置本机主机名:

`hostname {{新主机名}}`
